# count number of features using Kclause/Kmax, based on https://github.com/ekuiter/feature-model-repository-pipeline
cat eval_kmax.csv | grep ^linux | sort -V | cut -d, -f2-3 > features.csv
join -t, versions.csv features.csv > linux-features.csv

# count number of products using the d4 #SAT solver
rm -rf products.csv
for f in $(ls models/linux/*.kmax.dimacs | sort -V); do
	version=$(basename $f .kmax.dimacs)
	start=`date +%s.%N`
	countlog=$(echo "scale=2; l($(timeout 3600 ./d4 $f | grep ^s | cut -d' ' -f2))/l(10)" | bc -l)
	end=`date +%s.%N`
	line=$version,$countlog,$(echo "($end - $start) * 1000 / 1" | bc)
	echo $line
	echo $line >> products.csv
done
join -t, versions.csv products.csv > linux-products.csv

# count number of source lines of code using CLOC
for tag in $(git tag | grep -v rc | grep -v tree | grep -v v2.6.11); do
	echo $tag
	cloc --git $tag > ../sloc/$tag.txt
done
for f in sloc/*.txt; do
	echo $(basename $f .txt),$(cat $f | grep ^SUM | tr -s ' ' | cut -d' ' -f5) >> sloc.csv
done
join -t, versions.csv sloc.csv > linux-sloc.csv
